import cv2
import os
import tkinter as tk
from tkinterdnd2 import TkinterDnD, DND_FILES
from tkinter import Label, Button, Toplevel

def process_image(image_path):
    # Load the image
    img = cv2.imread(image_path)

    if img is None:
        print("Error: Image not found.")
    else:
        frameWidth = 1000   # Frame Width
        frameHeight = 480   # Frame Height

        # Ensure the Haar cascade file is in the correct path
        cascade_path = "haarcascade_russian_plate_number.xml"
        if not os.path.exists(cascade_path):
            print(f"Error: Haar cascade file '{cascade_path}' not found.")
            return

        plateCascade = cv2.CascadeClassifier(cascade_path)
        minArea = 500

        img = cv2.resize(img, (frameWidth, frameHeight))

        imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Adjusting the parameters for detectMultiScale
        numberPlates = plateCascade.detectMultiScale(imgGray, scaleFactor=1.1, minNeighbors=10, minSize=(30, 30))

        for (x, y, w, h) in numberPlates:
            area = w * h
            if area > minArea:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv2.putText(img, "NumberPlate", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
                imgRoi = img[y:y + h, x:x + w]
                cv2.imshow("Number Plate", imgRoi)

        cv2.imshow("Result", img)
        if cv2.waitKey(0) & 0xFF == ord('s'):  # Wait for the 's' key to save the image
            os.makedirs("./IMAGES", exist_ok=True)
            cv2.imwrite(f"./IMAGES/{os.path.basename(image_path)}", imgRoi)  # Save the ROI image
            cv2.rectangle(img, (0, 200), (640, 300), (0, 255, 0), cv2.FILLED)
            cv2.putText(img, "Scan Saved", (15, 265), cv2.FONT_HERSHEY_COMPLEX, 2, (0, 0, 255), 2)
            cv2.imshow("Result", img)
            cv2.waitKey(500)

        cv2.destroyAllWindows()

def drop(event):
    image_path = event.data
    if image_path:
        image_path = image_path.strip('{}')
        process_image(image_path)

def drag_and_drop_mode():
    # Create the main window
    root = TkinterDnD.Tk()
    root.title("Drag and Drop Image")
    root.geometry("400x200")

    label = Label(root, text="Drag and drop an image file here", bg="lightgray", fg="black")
    label.pack(expand=True, fill=tk.BOTH)

    # Register the drop event
    root.drop_target_register(DND_FILES)
    root.dnd_bind('<<Drop>>', drop)

    # Run the application
    root.mainloop()

def real_time_detection_mode():
    frameWidth = 1000   # Frame Width
    frameHeight = 480   # Frame Height

    # Ensure the Haar cascade file is in the correct path
    cascade_path = "C:/Users/abhis/OneDrive/Desktop/ANPR_with_opencv-main/ANPR_with_opencv-main/haarcascade_russian_plate_number.xml"
    if not os.path.exists(cascade_path):
        print(f"Error: Haar cascade file '{cascade_path}' not found.")
        return

    plateCascade = cv2.CascadeClassifier(cascade_path)
    minArea = 500

    cap = cv2.VideoCapture(0)
    cap.set(3, frameWidth)
    cap.set(4, frameHeight)
    cap.set(10, 150)
    count = 0

    while True:
        success, img = cap.read()
        imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        numberPlates = plateCascade.detectMultiScale(imgGray, scaleFactor=1.1, minNeighbors=10, minSize=(30, 30))

        for (x, y, w, h) in numberPlates:
            area = w * h
            if area > minArea:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv2.putText(img, "NumberPlate", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
                imgRoi = img[y:y + h, x:x + w]
                cv2.imshow("Number Plate", imgRoi)

        cv2.imshow("Result", img)
        if cv2.waitKey(1) & 0xFF == ord('s'):
            os.makedirs("./IMAGES", exist_ok=True)
            cv2.imwrite(f"./IMAGES/{count}.jpg", imgRoi)  # Save the ROI image
            cv2.rectangle(img, (0, 200), (640, 300), (0, 255, 0), cv2.FILLED)
            cv2.putText(img, "Scan Saved", (15, 265), cv2.FONT_HERSHEY_COMPLEX, 2, (0, 0, 255), 2)
            cv2.imshow("Result", img)
            cv2.waitKey(500)
            count += 1

def open_mode_selection_window():
    # Create the main window
    root = tk.Tk()
    root.title("Select Mode")
    root.geometry("300x150")

    label = Label(root, text="Select mode:", font=("Arial", 14))
    label.pack(pady=10)

    btn_drag_drop = Button(root, text="Drag and Drop Image", command=lambda: [root.destroy(), drag_and_drop_mode()])
    btn_drag_drop.pack(pady=5)

    btn_real_time = Button(root, text="Real-Time Detection", command=lambda: [root.destroy(), real_time_detection_mode()])
    btn_real_time.pack(pady=5)

    # Run the application
    root.mainloop()

if __name__ == "__main__":
    open_mode_selection_window()
